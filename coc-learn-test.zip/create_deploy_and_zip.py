import os
import shutil
import zipfile
import sys
import codecs

sys.stdout = codecs.getwriter('utf-8')(sys.stdout.detach())

src_dir = os.path.abspath(r'C:\Users\LENOVO\.gemini\antigravity\scratch\coc-learn-test')
scratch_dir = os.path.dirname(src_dir)
deploy_dir = os.path.join(scratch_dir, 'coc-learn-test-deploy')
zip_path = os.path.join(scratch_dir, 'coc-learn-test.zip')
deploy_zip_path = os.path.join(scratch_dir, 'coc-learn-test-deploy.zip')

print(f"Source Directory: {src_dir}")
print(f"Deploy Directory: {deploy_dir}")
print(f"Target Zip Path:  {zip_path}")

# 1. Create clean deploy directory
if os.path.exists(deploy_dir):
    print(f"Removing existing deploy directory: {deploy_dir}...")
    shutil.rmtree(deploy_dir)

def ignore_patterns(path, names):
    ignored = []
    for name in names:
        if name in ('__pycache__', '.git', 'node_modules', '.tmp', 'find_sensitive.py', 'sanitize_scripts.py'):
            ignored.append(name)
        elif name.endswith(('.pyc', '.tmp', '.log')):
            ignored.append(name)
    return ignored

print("Copying files to deploy directory...")
shutil.copytree(src_dir, deploy_dir, ignore=ignore_patterns)
print(f"✅ Successfully copied to deploy folder: {deploy_dir}")

# 2. Create zip archive of the deploy directory
print(f"Creating ZIP archive: {zip_path}...")
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(deploy_dir):
        for file in files:
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, deploy_dir)
            zipf.write(file_path, arcname)

zip_size_mb = os.path.getsize(zip_path) / (1024 * 1024)
print(f"✅ ZIP file created successfully: {zip_path} ({zip_size_mb:.2f} MB)")

# Also create deploy_zip copy
shutil.copyfile(zip_path, deploy_zip_path)
print(f"✅ Copy of ZIP created at: {deploy_zip_path}")

# Also copy zip into the project root so it is immediately accessible inside the active workspace
local_zip = os.path.join(src_dir, 'coc-learn-test.zip')
shutil.copyfile(zip_path, local_zip)
print(f"✅ Local project ZIP placed at: {local_zip}")
