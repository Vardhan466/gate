/**
 * COC Learn & Test — Firebase Cloud Functions
 * ============================================
 * Entry point for all server-side logic.
 *
 * Functions exported:
 *  1. gradeAttempt          — HTTPS Callable
 *  2. importDriveContent    — HTTPS Callable (admin only)
 *  3. generateTestsForTopic — HTTPS Callable (admin only)
 *  4. detectWeakTopics      — Scheduled (daily at 02:00 UTC)
 *  5. checkBadges           — HTTPS Callable
 */

import * as functions from "firebase-functions";
import * as admin from "firebase-admin";
import { google } from "googleapis";

// ─── Initialise Admin SDK ────────────────────────────────────────────────────
admin.initializeApp();
const db = admin.firestore();
db.settings({ ignoreUndefinedProperties: true });

// ─── Firestore timestamp helper ──────────────────────────────────────────────
const { FieldValue, Timestamp } = admin.firestore;

// ════════════════════════════════════════════════════════════════════════════
//  TYPE INTERFACES
// ════════════════════════════════════════════════════════════════════════════

/** Multiple-choice option keys */
type OptionKey = "A" | "B" | "C" | "D";

/** A single exam question stored in Firestore */
interface Question {
  id: string;
  topicId: string;
  testId?: string;
  questionNumber: number;
  questionText: string;
  options: Record<OptionKey, string>;
  correctAnswer: OptionKey;
  explanation?: string;
  difficulty?: "easy" | "medium" | "hard";
  tags?: string[];
}

/** A test attempt document */
interface Attempt {
  id: string;
  userId: string;
  testId: string;
  topicId: string;
  status: "in-progress" | "submitted" | "graded";
  answers: Record<string, OptionKey>;
  startedAt: FirebaseFirestore.Timestamp;
  submittedAt?: FirebaseFirestore.Timestamp;
  score?: number;
  totalQuestions?: number;
  percentage?: number;
  accuracy?: number;
  correct?: number;
  incorrect?: number;
  unanswered?: number;
}

/** Per-question result returned to the client after grading */
interface QuestionResult {
  questionId: string;
  isCorrect: boolean;
  correctAnswer: OptionKey;
  explanation: string;
  userAnswer: OptionKey | null;
}

/** Grading response payload */
interface GradeResponse {
  score: number;
  totalQuestions: number;
  percentage: number;
  accuracy: number;
  correct: number;
  incorrect: number;
  unanswered: number;
  results: QuestionResult[];
}

/** Progress document stored under /progress/{uid}/topics/{topicId} */
interface TopicProgress {
  topicId: string;
  totalAttempts: number;
  totalQuestionsAttempted: number;
  totalCorrect: number;
  averageAccuracy: number;
  lastAttemptAt: FirebaseFirestore.Timestamp;
  bestScore: number;
  weakAreas: string[];
}

/** Badge definition (stored in /adminData/badges) */
interface BadgeDefinition {
  id: string;
  name: string;
  description: string;
  iconUrl: string;
  criteria: BadgeCriteria;
}

type BadgeCriteria =
  | { type: "attempts_count"; threshold: number }
  | { type: "accuracy_threshold"; accuracy: number; minAttempts: number }
  | { type: "perfect_score"; count: number }
  | { type: "streak"; days: number }
  | { type: "topics_completed"; count: number };

/** User stats aggregated from attempts */
interface UserStats {
  totalAttempts: number;
  totalCorrect: number;
  totalQuestions: number;
  perfectScores: number;
  topicsCompleted: string[];
  streakDays: number;
  accuracy: number;
}

/** Drive import report */
interface ImportReport {
  topicsImported: number;
  questionsImported: number;
  duplicates: number;
  errors: string[];
  testsGenerated: number;
  topicIds: string[];
  importedAt: FirebaseFirestore.Timestamp;
}

// ════════════════════════════════════════════════════════════════════════════
//  FUNCTION 1: gradeAttempt
//  HTTPS Callable — triggered by the client after test submission
// ════════════════════════════════════════════════════════════════════════════

/**
 * Grades a student's test attempt server-side.
 *
 * Input  : { attemptId, testId, answers: { [questionId]: OptionKey } }
 * Returns: GradeResponse with per-question results for instant review
 *
 * Side-effects:
 *  - Updates the attempt document with grade data
 *  - Updates /progress/{uid}/topics/{topicId}
 *  - Calls checkBadgesInternal()
 *  - Creates a notification document
 */
export const gradeAttempt = functions
  .runWith({ timeoutSeconds: 120, memory: "512MB" })
  .https.onCall(async (data, context) => {
    // ── Auth guard ──────────────────────────────────────────────────────────
    if (!context.auth) {
      throw new functions.https.HttpsError(
        "unauthenticated",
        "You must be signed in to submit an attempt."
      );
    }
    const userId = context.auth.uid;

    // ── Input validation ────────────────────────────────────────────────────
    const { attemptId, testId, answers } = data as {
      attemptId: string;
      testId: string;
      answers: Record<string, OptionKey>;
    };

    if (!attemptId || !testId || !answers) {
      throw new functions.https.HttpsError(
        "invalid-argument",
        "Required fields: attemptId, testId, answers."
      );
    }

    // ── Verify attempt ownership ────────────────────────────────────────────
    const attemptRef = db.collection("attempts").doc(attemptId);
    const attemptSnap = await attemptRef.get();

    if (!attemptSnap.exists) {
      throw new functions.https.HttpsError("not-found", "Attempt not found.");
    }

    const attempt = attemptSnap.data() as Attempt;

    if (attempt.userId !== userId) {
      throw new functions.https.HttpsError(
        "permission-denied",
        "You do not own this attempt."
      );
    }

    if (attempt.status === "graded" || attempt.status === "submitted") {
      throw new functions.https.HttpsError(
        "failed-precondition",
        "This attempt has already been graded."
      );
    }

    // ── Fetch all questions for the test (Admin SDK — bypasses rules) ───────
    const questionsSnap = await db
      .collection("questions")
      .where("testId", "==", testId)
      .orderBy("questionNumber", "asc")
      .get();

    if (questionsSnap.empty) {
      throw new functions.https.HttpsError(
        "not-found",
        `No questions found for testId: ${testId}`
      );
    }

    const questions = questionsSnap.docs.map((d) => ({
      id: d.id,
      ...(d.data() as Omit<Question, "id">),
    })) as Question[];

    const topicId = questions[0].topicId;

    // ── Grade each question ─────────────────────────────────────────────────
    let correct = 0;
    let incorrect = 0;
    let unanswered = 0;

    const results: QuestionResult[] = questions.map((q) => {
      const userAnswer: OptionKey | null = answers[q.id] ?? null;
      const isCorrect = userAnswer === q.correctAnswer;

      if (userAnswer === null) {
        unanswered++;
      } else if (isCorrect) {
        correct++;
      } else {
        incorrect++;
      }

      return {
        questionId: q.id,
        isCorrect,
        correctAnswer: q.correctAnswer,
        explanation: q.explanation ?? "",
        userAnswer,
      };
    });

    const totalQuestions = questions.length;
    const attempted = correct + incorrect;
    const score = correct; // 1 mark per correct answer; adjust if negative marking needed
    const percentage = parseFloat(((score / totalQuestions) * 100).toFixed(2));
    const accuracy = attempted > 0
      ? parseFloat(((correct / attempted) * 100).toFixed(2))
      : 0;

    const gradePayload: GradeResponse = {
      score,
      totalQuestions,
      percentage,
      accuracy,
      correct,
      incorrect,
      unanswered,
      results,
    };

    // ── Batch write: update attempt + progress + notification ───────────────
    const batch = db.batch();
    const now = Timestamp.now();

    // 1) Update attempt document
    batch.update(attemptRef, {
      status: "graded",
      submittedAt: now,
      answers,
      score,
      totalQuestions,
      percentage,
      accuracy,
      correct,
      incorrect,
      unanswered,
      topicId,
      gradedAt: now,
    });

    // 2) Update /progress/{userId}/topics/{topicId}
    const progressRef = db
      .collection("progress")
      .doc(userId)
      .collection("topics")
      .doc(topicId);

    const progressSnap = await progressRef.get();

    if (progressSnap.exists) {
      const prev = progressSnap.data() as TopicProgress;
      const newTotal = prev.totalAttempts + 1;
      const newTotalQ = prev.totalQuestionsAttempted + totalQuestions;
      const newTotalC = prev.totalCorrect + correct;
      const newAccuracy = parseFloat(((newTotalC / newTotalQ) * 100).toFixed(2));

      batch.update(progressRef, {
        totalAttempts: newTotal,
        totalQuestionsAttempted: newTotalQ,
        totalCorrect: newTotalC,
        averageAccuracy: newAccuracy,
        lastAttemptAt: now,
        bestScore: Math.max(prev.bestScore ?? 0, percentage),
      });
    } else {
      batch.set(progressRef, {
        topicId,
        totalAttempts: 1,
        totalQuestionsAttempted: totalQuestions,
        totalCorrect: correct,
        averageAccuracy: accuracy,
        lastAttemptAt: now,
        bestScore: percentage,
        weakAreas: [],
      } as TopicProgress);
    }

    // 3) Also update summary document /progress/{userId}
    const progressSummaryRef = db.collection("progress").doc(userId);
    batch.set(
      progressSummaryRef,
      {
        lastActivityAt: now,
        totalAttempts: FieldValue.increment(1),
        totalCorrect: FieldValue.increment(correct),
        totalQuestions: FieldValue.increment(totalQuestions),
      },
      { merge: true }
    );

    // 4) Create notification
    const notifRef = db
      .collection("notifications")
      .doc(userId)
      .collection("items")
      .doc();

    batch.set(notifRef, {
      type: "test_graded",
      title: "Test Graded",
      body: `Your test has been graded. Score: ${score}/${totalQuestions} (${percentage}%)`,
      attemptId,
      testId,
      topicId,
      read: false,
      createdAt: now,
    });

    await batch.commit();

    // ── Award badges (non-blocking — failures don't break grading) ──────────
    try {
      await checkBadgesInternal(userId);
    } catch (err) {
      functions.logger.error("checkBadges failed after grading", { userId, err });
    }

    functions.logger.info("Attempt graded", {
      attemptId, userId, testId, score, percentage,
    });

    return gradePayload;
  });

// ════════════════════════════════════════════════════════════════════════════
//  FUNCTION 2: importDriveContent
//  HTTPS Callable — admin only
// ════════════════════════════════════════════════════════════════════════════

/**
 * Imports question content from a Google Drive folder.
 *
 * Input  : { driveFolderId: string, adminUid: string }
 * Returns: ImportReport
 *
 * Workflow:
 *  1. Verify caller is admin
 *  2. List files in Drive folder via Drive API
 *  3. Parse each file into Question objects
 *  4. Validate, deduplicate, batch-write to Firestore
 *  5. Auto-generate test assignments via generateTestsForTopicInternal()
 *  6. Write import report to /adminData/importReports
 */
export const importDriveContent = functions
  .runWith({ timeoutSeconds: 540, memory: "1GB" })
  .https.onCall(async (data, context) => {
    // ── Admin guard ─────────────────────────────────────────────────────────
    if (!context.auth) {
      throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
    }

    const isAdmin =
      context.auth.token.role === "admin" ||
      (await db.collection("users").doc(context.auth.uid).get()).data()?.role === "admin";

    if (!isAdmin) {
      throw new functions.https.HttpsError(
        "permission-denied",
        "Only administrators can import content."
      );
    }

    const { driveFolderId } = data as { driveFolderId: string; adminUid: string };

    if (!driveFolderId) {
      throw new functions.https.HttpsError(
        "invalid-argument",
        "driveFolderId is required."
      );
    }

    // ── Initialise Drive API using service account credentials ──────────────
    const driveConfig = functions.config().drive ?? {};
    const auth = new google.auth.GoogleAuth({
      credentials: {
        client_email: driveConfig.client_email,
        private_key: (driveConfig.private_key ?? "").replace(/\\n/g, "\n"),
      },
      scopes: ["https://www.googleapis.com/auth/drive.readonly"],
    });

    const drive = google.drive({ version: "v3", auth });

    // ── List all files in the Drive folder ──────────────────────────────────
    let driveFiles: Array<{ id: string; name: string; mimeType: string }> = [];

    try {
      const listRes = await drive.files.list({
        q: `'${driveFolderId}' in parents and trashed = false`,
        fields: "files(id, name, mimeType)",
        pageSize: 1000,
      });
      driveFiles = (listRes.data.files ?? []) as typeof driveFiles;
    } catch (err) {
      functions.logger.error("Drive API list failed", err);
      throw new functions.https.HttpsError(
        "internal",
        "Failed to list Drive folder. Check service account permissions."
      );
    }

    if (driveFiles.length === 0) {
      throw new functions.https.HttpsError(
        "not-found",
        "No files found in the specified Drive folder."
      );
    }

    functions.logger.info(`Found ${driveFiles.length} files in Drive folder`, { driveFolderId });

    // ── Process each file ───────────────────────────────────────────────────
    const report: ImportReport = {
      topicsImported: 0,
      questionsImported: 0,
      duplicates: 0,
      errors: [],
      testsGenerated: 0,
      topicIds: [],
      importedAt: Timestamp.now(),
    };

    // Map to group questions by topic name
    const topicQuestionMap = new Map<string, Question[]>();

    for (const file of driveFiles) {
      try {
        const parsed = await parseQuestionFile(drive, file.id, file.name);
        if (!parsed) continue;

        const { topicName, questions } = parsed;
        if (!topicQuestionMap.has(topicName)) {
          topicQuestionMap.set(topicName, []);
        }
        topicQuestionMap.get(topicName)!.push(...questions);
      } catch (err) {
        const msg = `Error parsing file "${file.name}": ${(err as Error).message}`;
        report.errors.push(msg);
        functions.logger.warn(msg);
      }
    }

    // ── Write topics and questions to Firestore ─────────────────────────────
    for (const [topicName, questions] of topicQuestionMap.entries()) {
      try {
        // Upsert topic document (idempotent)
        const topicId = slugify(topicName);
        const topicRef = db.collection("topics").doc(topicId);
        await topicRef.set(
          {
            name: topicName,
            slug: topicId,
            questionCount: questions.length,
            updatedAt: Timestamp.now(),
            createdAt: FieldValue.serverTimestamp(),
          },
          { merge: true }
        );

        // Deduplicate against existing questions
        const existingSnap = await db
          .collection("questions")
          .where("topicId", "==", topicId)
          .get();

        const existingNumbers = new Set(
          existingSnap.docs.map((d) => d.data().questionNumber as number)
        );

        const newQuestions = questions.filter(
          (q) => !existingNumbers.has(q.questionNumber)
        );
        report.duplicates += questions.length - newQuestions.length;

        // Batch write new questions (500 per batch — Firestore limit)
        const BATCH_SIZE = 450;
        for (let i = 0; i < newQuestions.length; i += BATCH_SIZE) {
          const batch = db.batch();
          const chunk = newQuestions.slice(i, i + BATCH_SIZE);

          for (const q of chunk) {
            const qRef = db.collection("questions").doc();
            batch.set(qRef, {
              ...q,
              topicId,
              createdAt: FieldValue.serverTimestamp(),
            });
          }

          await batch.commit();
          report.questionsImported += chunk.length;
        }

        // Auto-generate tests for this topic
        const testResult = await generateTestsForTopicInternal(topicId, questions.length);
        report.testsGenerated += testResult.testsCreated;

        report.topicsImported++;
        report.topicIds.push(topicId);

        functions.logger.info(`Imported topic "${topicName}"`, {
          topicId,
          questionsAdded: newQuestions.length,
        });
      } catch (err) {
        const msg = `Failed to write topic "${topicName}": ${(err as Error).message}`;
        report.errors.push(msg);
        functions.logger.error(msg, err);
      }
    }

    // ── Save import report ──────────────────────────────────────────────────
    const reportRef = db.collection("adminData").doc("importReports")
      .collection("reports").doc();

    await reportRef.set({
      ...report,
      triggeredBy: context.auth.uid,
      driveFolderId,
    });

    functions.logger.info("Import complete", report);
    return report;
  });

// ─── Internal: parse a Drive file into topic + questions ─────────────────────

/**
 * Downloads and parses a Google Drive file into a structured question list.
 * Supports plain text (.txt) files with the following format per question:
 *
 *   Q1. Question text here?
 *   A) Option A text
 *   B) Option B text
 *   C) Option C text
 *   D) Option D text
 *   ANSWER: B
 *   EXPLANATION: Brief explanation (optional)
 *   ---
 *
 * The topic name is derived from the file name (minus extension).
 */
async function parseQuestionFile(
  drive: ReturnType<typeof google.drive>,
  fileId: string,
  fileName: string
): Promise<{ topicName: string; questions: Question[] } | null> {
  // Download file content as text
  const res = await drive.files.get(
    { fileId, alt: "media" },
    { responseType: "text" }
  );

  const raw = res.data as string;
  if (!raw || raw.trim().length === 0) return null;

  const topicName = fileName.replace(/\.[^/.]+$/, "").replace(/_/g, " ").trim();
  const questions: Question[] = [];

  // Split into individual question blocks by '---' delimiter
  const blocks = raw.split(/^---+$/m).map((b) => b.trim()).filter(Boolean);

  for (let i = 0; i < blocks.length; i++) {
    const block = blocks[i];
    try {
      const q = parseQuestionBlock(block, i + 1);
      if (q) questions.push(q);
    } catch {
      functions.logger.warn(`Could not parse block ${i + 1} in ${fileName}`);
    }
  }

  return { topicName, questions };
}

/** Parses a single question block string into a Question object */
function parseQuestionBlock(block: string, number: number): Question | null {
  const lines = block.split("\n").map((l) => l.trim()).filter(Boolean);
  if (lines.length < 6) return null;

  const questionLines: string[] = [];
  const options: Partial<Record<OptionKey, string>> = {};
  let correctAnswer: OptionKey | null = null;
  let explanation = "";

  for (const line of lines) {
    if (/^Q\d+\./i.test(line)) {
      questionLines.push(line.replace(/^Q\d+\.\s*/i, "").trim());
    } else if (/^ANSWER:/i.test(line)) {
      const ans = line.replace(/^ANSWER:\s*/i, "").trim().toUpperCase() as OptionKey;
      if (["A", "B", "C", "D"].includes(ans)) correctAnswer = ans;
    } else if (/^EXPLANATION:/i.test(line)) {
      explanation = line.replace(/^EXPLANATION:\s*/i, "").trim();
    } else if (/^[A-D][.)]/i.test(line)) {
      const key = line[0].toUpperCase() as OptionKey;
      options[key] = line.replace(/^[A-D][.)]\s*/i, "").trim();
    } else {
      // Continuation of question text
      if (questionLines.length > 0) {
        questionLines.push(line);
      }
    }
  }

  if (!correctAnswer || Object.keys(options).length < 4) return null;

  return {
    id: "",
    topicId: "",
    questionNumber: number,
    questionText: questionLines.join(" "),
    options: options as Record<OptionKey, string>,
    correctAnswer,
    explanation,
    difficulty: "medium",
    tags: [],
  };
}

/** Converts a string to a URL-safe slug */
function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9-]/g, "")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}

// ════════════════════════════════════════════════════════════════════════════
//  FUNCTION 3: generateTestsForTopic
//  HTTPS Callable — admin only
// ════════════════════════════════════════════════════════════════════════════

/**
 * Splits all questions for a topic into groups of 40 and creates test documents.
 *
 * Input  : { topicId: string, totalQuestions: number }
 * Returns: { testsCreated: number, testIds: string[] }
 */
export const generateTestsForTopic = functions
  .runWith({ timeoutSeconds: 120, memory: "256MB" })
  .https.onCall(async (data, context) => {
    if (!context.auth) {
      throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
    }

    const isAdmin =
      context.auth.token.role === "admin" ||
      (await db.collection("users").doc(context.auth.uid).get()).data()?.role === "admin";

    if (!isAdmin) {
      throw new functions.https.HttpsError(
        "permission-denied",
        "Only administrators can generate tests."
      );
    }

    const { topicId, totalQuestions } = data as {
      topicId: string;
      totalQuestions: number;
    };

    if (!topicId) {
      throw new functions.https.HttpsError("invalid-argument", "topicId is required.");
    }

    return generateTestsForTopicInternal(topicId, totalQuestions);
  });

/**
 * Internal implementation — can be called from importDriveContent as well.
 * Groups questions into sets of 40 and writes test documents.
 */
async function generateTestsForTopicInternal(
  topicId: string,
  totalQuestions: number
): Promise<{ testsCreated: number; testIds: string[] }> {
  const QUESTIONS_PER_TEST = 40;

  // Fetch all questions for the topic ordered by questionNumber
  const questionsSnap = await db
    .collection("questions")
    .where("topicId", "==", topicId)
    .orderBy("questionNumber", "asc")
    .get();

  const allQuestions = questionsSnap.docs;
  const total = allQuestions.length || totalQuestions;

  const numTests = Math.ceil(total / QUESTIONS_PER_TEST);
  const testIds: string[] = [];

  const batch = db.batch();

  for (let i = 0; i < numTests; i++) {
    const chunk = allQuestions.slice(
      i * QUESTIONS_PER_TEST,
      (i + 1) * QUESTIONS_PER_TEST
    );
    const questionIds = chunk.map((d) => d.id);
    const testNumber = i + 1;

    // Use deterministic ID so re-runs overwrite rather than duplicate
    const testId = `${topicId}_test_${String(testNumber).padStart(3, "0")}`;
    const testRef = db.collection("tests").doc(testId);

    batch.set(testRef, {
      topicId,
      testNumber,
      title: `Test ${testNumber}`,
      totalQuestions: questionIds.length || QUESTIONS_PER_TEST,
      questionIds,
      status: "active",
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    });

    // Back-link questions to this test
    for (const qDoc of chunk) {
      batch.update(qDoc.ref, { testId });
    }

    testIds.push(testId);
  }

  await batch.commit();

  functions.logger.info("Tests generated", { topicId, numTests, testIds });
  return { testsCreated: numTests, testIds };
}

// ════════════════════════════════════════════════════════════════════════════
//  FUNCTION 4: detectWeakTopics
//  Scheduled — runs daily at 02:00 UTC
// ════════════════════════════════════════════════════════════════════════════

/**
 * Scans all active users' attempt history, identifies topics where average
 * accuracy falls below 70%, updates /progress/{uid}/weakTopics, and sends
 * a push notification recommending revision.
 *
 * Runs server-side in small pages to avoid memory limits.
 */
export const detectWeakTopics = functions
  .runWith({ timeoutSeconds: 540, memory: "512MB" })
  .pubsub.schedule("0 2 * * *")   // daily at 02:00 UTC
  .timeZone("UTC")
  .onRun(async (_context) => {
    const WEAK_ACCURACY_THRESHOLD = 70; // percent
    let processedUsers = 0;
    let usersWithWeakTopics = 0;

    // Page through all active users in batches of 200
    let lastDoc: FirebaseFirestore.DocumentSnapshot | null = null;

    while (true) {
      let query = db
        .collection("users")
        .where("status", "==", "active")
        .limit(200);

      if (lastDoc) query = query.startAfter(lastDoc);

      const usersSnap = await query.get();
      if (usersSnap.empty) break;

      lastDoc = usersSnap.docs[usersSnap.docs.length - 1];

      // Process each user
      await Promise.all(
        usersSnap.docs.map(async (userDoc) => {
          const uid = userDoc.id;
          try {
            const weakTopics = await findWeakTopicsForUser(uid, WEAK_ACCURACY_THRESHOLD);

            // Update /progress/{uid}/weakTopics
            const weakRef = db.collection("progress").doc(uid);
            await weakRef.set(
              { weakTopics, weakTopicsUpdatedAt: Timestamp.now() },
              { merge: true }
            );

            if (weakTopics.length > 0) {
              usersWithWeakTopics++;
              // Send push notification if user has an FCM token
              const userData = userDoc.data();
              const fcmToken = userData?.fcmToken as string | undefined;

              if (fcmToken) {
                await sendWeakTopicsNotification(uid, fcmToken, weakTopics);
              }
            }

            processedUsers++;
          } catch (err) {
            functions.logger.error(`detectWeakTopics: failed for user ${uid}`, err);
          }
        })
      );

      if (usersSnap.size < 200) break; // Last page
    }

    functions.logger.info("detectWeakTopics complete", {
      processedUsers,
      usersWithWeakTopics,
      ranAt: new Date().toISOString(),
    });
  });

/** Returns topic IDs where the user's average accuracy is below threshold */
async function findWeakTopicsForUser(
  uid: string,
  threshold: number
): Promise<string[]> {
  const topicsSnap = await db
    .collection("progress")
    .doc(uid)
    .collection("topics")
    .get();

  return topicsSnap.docs
    .filter((d) => {
      const data = d.data() as TopicProgress;
      return (
        data.totalAttempts >= 2 && // Need at least 2 attempts for reliability
        data.averageAccuracy < threshold
      );
    })
    .map((d) => d.id);
}

/** Sends an FCM push notification recommending weak topic revision */
async function sendWeakTopicsNotification(
  uid: string,
  fcmToken: string,
  weakTopics: string[]
): Promise<void> {
  const topicCount = weakTopics.length;
  const message: admin.messaging.Message = {
    token: fcmToken,
    notification: {
      title: "📚 Time to Revise!",
      body: `You have ${topicCount} topic${topicCount > 1 ? "s" : ""} that need${topicCount === 1 ? "s" : ""} attention. Keep improving!`,
    },
    data: {
      type: "weak_topics",
      weakTopics: weakTopics.join(","),
      uid,
    },
    android: { priority: "normal" },
    apns: { headers: { "apns-priority": "5" } },
  };

  await admin.messaging().send(message);

  // Also create an in-app notification document
  await db
    .collection("notifications")
    .doc(uid)
    .collection("items")
    .add({
      type: "weak_topics",
      title: "Revision Recommended",
      body: `You have ${topicCount} weak topic${topicCount > 1 ? "s" : ""}. Revisit them to improve your accuracy.`,
      weakTopics,
      read: false,
      createdAt: Timestamp.now(),
    });
}

// ════════════════════════════════════════════════════════════════════════════
//  FUNCTION 5: checkBadges
//  HTTPS Callable — triggers badge evaluation for a user
// ════════════════════════════════════════════════════════════════════════════

/**
 * Evaluates all badge criteria against a user's current stats and awards
 * any newly earned badges. Also called internally by gradeAttempt.
 *
 * Input  : { userId: string }
 * Returns: { newBadges: string[], totalBadges: number }
 */
export const checkBadges = functions
  .runWith({ timeoutSeconds: 60, memory: "256MB" })
  .https.onCall(async (data, context) => {
    if (!context.auth) {
      throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
    }

    const { userId } = data as { userId: string };

    // Users may only check their own badges; admins can check any user
    const isAdmin = context.auth.token.role === "admin";
    if (!isAdmin && context.auth.uid !== userId) {
      throw new functions.https.HttpsError(
        "permission-denied",
        "You can only check your own badges."
      );
    }

    return checkBadgesInternal(userId);
  });

/**
 * Internal badge-checking logic — callable from within other functions.
 */
async function checkBadgesInternal(
  userId: string
): Promise<{ newBadges: string[]; totalBadges: number }> {
  // ── Gather user stats ─────────────────────────────────────────────────────
  const [summarySnap, badgesSnap, badgeDefsSnap] = await Promise.all([
    db.collection("progress").doc(userId).get(),
    db.collection("badges").doc(userId).collection("earned").get(),
    db.collection("adminData").doc("badgeDefinitions").get(),
  ]);

  if (!badgeDefsSnap.exists) {
    functions.logger.warn("No badge definitions found in adminData/badgeDefinitions");
    return { newBadges: [], totalBadges: 0 };
  }

  const summary = summarySnap.data() ?? {};
  const earnedBadgeIds = new Set(badgesSnap.docs.map((d) => d.id));
  const badgeDefs = badgeDefsSnap.data()?.badges as BadgeDefinition[] ?? [];

  // Fetch topic-level progress for topics_completed criterion
  const topicsSnap = await db
    .collection("progress")
    .doc(userId)
    .collection("topics")
    .get();

  const completedTopics = topicsSnap.docs
    .filter((d) => (d.data().totalAttempts ?? 0) >= 1)
    .map((d) => d.id);

  const userStats: UserStats = {
    totalAttempts: summary.totalAttempts ?? 0,
    totalCorrect: summary.totalCorrect ?? 0,
    totalQuestions: summary.totalQuestions ?? 0,
    perfectScores: summary.perfectScores ?? 0,
    topicsCompleted: completedTopics,
    streakDays: summary.streakDays ?? 0,
    accuracy:
      summary.totalQuestions > 0
        ? parseFloat(
            ((summary.totalCorrect / summary.totalQuestions) * 100).toFixed(2)
          )
        : 0,
  };

  // ── Evaluate each badge ───────────────────────────────────────────────────
  const newBadges: string[] = [];
  const batch = db.batch();
  const now = Timestamp.now();

  for (const badge of badgeDefs) {
    if (earnedBadgeIds.has(badge.id)) continue; // Already earned

    const earned = evaluateBadgeCriteria(badge.criteria, userStats);
    if (!earned) continue;

    // Award badge — writes to /badges/{uid}/earned/{badgeId}
    const badgeRef = db
      .collection("badges")
      .doc(userId)
      .collection("earned")
      .doc(badge.id);

    batch.set(badgeRef, {
      badgeId: badge.id,
      name: badge.name,
      description: badge.description,
      iconUrl: badge.iconUrl,
      earnedAt: now,
    });

    // Create notification for the new badge
    const notifRef = db
      .collection("notifications")
      .doc(userId)
      .collection("items")
      .doc();

    batch.set(notifRef, {
      type: "badge_earned",
      title: "🏅 New Badge Earned!",
      body: `You earned the "${badge.name}" badge! ${badge.description}`,
      badgeId: badge.id,
      badgeName: badge.name,
      badgeIconUrl: badge.iconUrl,
      read: false,
      createdAt: now,
    });

    newBadges.push(badge.id);
    functions.logger.info(`Badge awarded: ${badge.id}`, { userId });
  }

  if (newBadges.length > 0) {
    // Update badge count on user's progress summary
    batch.set(
      db.collection("progress").doc(userId),
      { totalBadges: FieldValue.increment(newBadges.length) },
      { merge: true }
    );

    await batch.commit();
  }

  return {
    newBadges,
    totalBadges: earnedBadgeIds.size + newBadges.length,
  };
}

/**
 * Checks whether the given UserStats satisfies a BadgeCriteria.
 * Returns true if the badge should be awarded.
 */
function evaluateBadgeCriteria(
  criteria: BadgeCriteria,
  stats: UserStats
): boolean {
  switch (criteria.type) {
    case "attempts_count":
      return stats.totalAttempts >= criteria.threshold;

    case "accuracy_threshold":
      return (
        stats.totalAttempts >= criteria.minAttempts &&
        stats.accuracy >= criteria.accuracy
      );

    case "perfect_score":
      return stats.perfectScores >= criteria.count;

    case "streak":
      return stats.streakDays >= criteria.days;

    case "topics_completed":
      return stats.topicsCompleted.length >= criteria.count;

    default:
      return false;
  }
}
