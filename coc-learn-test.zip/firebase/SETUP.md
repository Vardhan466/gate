# COC Learn & Test — Firebase Backend Setup Guide

Complete setup guide for deploying the COC Learn & Test Firebase backend from scratch.

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Firebase Project Creation](#2-firebase-project-creation)
3. [Enabling Firebase Services](#3-enabling-firebase-services)
4. [Service Account Setup (Drive API)](#4-service-account-setup-drive-api)
5. [Environment Variables](#5-environment-variables)
6. [Install Dependencies & Build](#6-install-dependencies--build)
7. [Deploy to Firebase](#7-deploy-to-firebase)
8. [First-Time Data Seeding](#8-first-time-data-seeding)
9. [Testing the Import Workflow](#9-testing-the-import-workflow)
10. [Emulator (Local Development)](#10-emulator-local-development)
11. [Troubleshooting](#11-troubleshooting)

---

## 1. Prerequisites

| Requirement | Minimum Version | Check Command |
|---|---|---|
| Node.js | 18.x LTS | `node --version` |
| npm | 9.x | `npm --version` |
| Firebase CLI | 12.x | `firebase --version` |
| Git | Any | `git --version` |
| Google Cloud SDK | Optional (for advanced IAM) | `gcloud --version` |

### Install Firebase CLI

```bash
npm install -g firebase-tools
firebase login
```

Verify login:

```bash
firebase projects:list
```

---

## 2. Firebase Project Creation

### Option A — Firebase Console (Recommended)

1. Go to **https://console.firebase.google.com**
2. Click **Add project**
3. Enter project name: `coc-learn-test` (or your preferred name)
4. Disable Google Analytics if not needed → **Create project**
5. Note your **Project ID** (e.g. `coc-learn-test-ab12c`)

### Option B — Firebase CLI

```bash
firebase projects:create coc-learn-test --display-name "COC Learn and Test"
```

### Link the local directory to your Firebase project

Inside `firebase/`:

```bash
firebase use --add
# Select your project from the list
# Give it an alias: default
```

This creates / updates `.firebaserc`:

```json
{
  "projects": {
    "default": "coc-learn-test-ab12c"
  }
}
```

---

## 3. Enabling Firebase Services

Open **Firebase Console → your project** and enable each service:

### 3.1 Authentication

1. **Build → Authentication → Get started**
2. Enable **Email/Password** provider
3. Enable **Google** provider (add your app's OAuth client ID)
4. *(Optional)* Enable **Phone** for OTP login

### 3.2 Firestore Database

1. **Build → Firestore Database → Create database**
2. Select **Production mode** (rules will be deployed separately)
3. Choose a region closest to your users (e.g. `asia-south1` for India)

> **Important:** Choose the region carefully — it cannot be changed later.

### 3.3 Cloud Functions

1. **Build → Functions → Get started**
2. Upgrade to **Blaze (pay-as-you-go)** plan — required for outbound network calls
3. Set a **billing budget alert** (recommended: ₹500/month)

### 3.4 Firebase Storage

1. **Build → Storage → Get started**
2. Start in **Production mode**
3. Use the same region as Firestore

### 3.5 Cloud Messaging (FCM)

1. **Build → Messaging → Get started**
2. No additional setup needed — used automatically by push notification code

### 3.6 Firebase Admin Custom Claims

To assign the `admin` role to a user via Firebase Admin SDK:

```javascript
// Run once from Node.js with service account credentials
const admin = require('firebase-admin');
admin.initializeApp({ credential: admin.credential.applicationDefault() });

await admin.auth().setCustomUserClaims('USER_UID_HERE', { role: 'admin' });
```

The user must sign out and sign back in for the claim to take effect.

---

## 4. Service Account Setup (Drive API)

Cloud Functions call the Google Drive API to import question files.
A dedicated service account is required.

### Step 1 — Create Service Account

1. Go to **Google Cloud Console → IAM & Admin → Service Accounts**
2. Click **Create Service Account**
   - Name: `coc-drive-importer`
   - Description: `Drive API access for COC Learn & Test content import`
3. Grant roles: **Viewer** (no broad permissions needed — only Drive file reads)
4. Click **Done**

### Step 2 — Create a JSON Key

1. Click on the new service account → **Keys** tab
2. **Add Key → Create new key → JSON**
3. Download the `.json` file — keep it **private and never commit it to Git**

The JSON file contains:

```json
{
  "type": "service_account",
  "project_id": "YOUR_PROJECT_ID",
  "private_key_id": "YOUR_KEY_ID",
  "private_key": "-----BEGIN RSA PRIVATE KEY-----\nYOUR_PRIVATE_KEY_HERE\n-----END RSA PRIVATE KEY-----\n",
  "client_email": "YOUR_SERVICE_ACCOUNT_EMAIL@YOUR_PROJECT_ID.iam.gserviceaccount.com",
  ...
}
```

### Step 3 — Share the Drive Folder with the Service Account

1. Open your Google Drive folder containing question files
2. Right-click → **Share**
3. Add the service account email: `YOUR_SERVICE_ACCOUNT_EMAIL@YOUR_PROJECT_ID.iam.gserviceaccount.com`
4. Set permission to **Viewer**

---

## 5. Environment Variables

Firebase Functions config stores secrets securely outside your source code.

### Set Drive API credentials

```bash
firebase functions:config:set \
  drive.client_email="YOUR_SERVICE_ACCOUNT_EMAIL@YOUR_PROJECT_ID.iam.gserviceaccount.com" \
  drive.private_key="-----BEGIN RSA PRIVATE KEY-----\nYOUR_PRIVATE_KEY_HERE\n-----END RSA PRIVATE KEY-----\n"
```

> **Note:** Replace `\n` in the private key with actual newlines when setting, or use the literal `\n` escape — the Cloud Function code handles `.replace(/\\n/g, "\n")` automatically.

### Set additional config (optional but recommended)

```bash
firebase functions:config:set \
  app.name="COC Learn and Test" \
  app.support_email="support@example.com" \
  app.admin_email="admin@example.com"
```

### Verify config

```bash
firebase functions:config:get
```

### For local emulator — export config to `.runtimeconfig.json`

```bash
firebase functions:config:get > functions/.runtimeconfig.json
```

> ⚠️ **Never commit `.runtimeconfig.json` to Git.** Add it to `.gitignore`.

---

## 6. Install Dependencies & Build

### Install Cloud Functions dependencies

```bash
cd firebase/functions
npm install
npm run build
```

Verify the `lib/` folder is generated with compiled JavaScript.

### Install frontend dependencies (if applicable)

```bash
cd ../../   # back to project root
npm install
npm run build   # generates dist/ for Firebase Hosting
```

---

## 7. Deploy to Firebase

### Deploy everything at once

```bash
cd firebase/
firebase deploy
```

### Deploy individual components

```bash
# Firestore rules only
firebase deploy --only firestore:rules

# Firestore indexes only
firebase deploy --only firestore:indexes

# Cloud Functions only
firebase deploy --only functions

# Firebase Hosting only
firebase deploy --only hosting
```

### Expected output

```
=== Deploying to 'coc-learn-test-ab12c'...

i  deploying firestore, functions, hosting
✔  firestore: released rules firestore.rules to cloud.firestore
✔  firestore: deployed indexes in firestore.indexes.json successfully
✔  functions: updated functions in us-central1
✔  hosting[coc-learn-test-ab12c]: release complete

✔  Deploy complete!
```

---

## 8. First-Time Data Seeding

### 8.1 Create Admin User

1. Register a user via the app's sign-up page (or Firebase Console → Authentication → Add user)
2. Copy the user's UID from Firebase Console → Authentication
3. Set admin custom claim:

```bash
# Run from a Node.js script with GOOGLE_APPLICATION_CREDENTIALS set
node seed/set-admin-claim.js <USER_UID>
```

Or via Firebase Admin SDK directly in Cloud Shell:

```javascript
admin.auth().setCustomUserClaims('UID_HERE', { role: 'admin' });
```

### 8.2 Create User Profile Document

After registering, create `/users/{uid}` with:

```json
{
  "uid": "USER_UID_HERE",
  "email": "admin@example.com",
  "displayName": "Platform Admin",
  "role": "admin",
  "status": "active",
  "createdAt": "<server timestamp>",
  "photoURL": null,
  "fcmToken": null
}
```

### 8.3 Seed Badge Definitions

Create `/adminData/badgeDefinitions` with your badge catalog:

```json
{
  "badges": [
    {
      "id": "first_attempt",
      "name": "First Step",
      "description": "Completed your first test attempt",
      "iconUrl": "https://storage.../badges/first_step.png",
      "criteria": { "type": "attempts_count", "threshold": 1 }
    },
    {
      "id": "ten_attempts",
      "name": "Dedicated Learner",
      "description": "Completed 10 test attempts",
      "iconUrl": "https://storage.../badges/dedicated.png",
      "criteria": { "type": "attempts_count", "threshold": 10 }
    },
    {
      "id": "accuracy_star",
      "name": "Accuracy Star",
      "description": "Maintained 90%+ accuracy over 5+ attempts",
      "iconUrl": "https://storage.../badges/accuracy_star.png",
      "criteria": { "type": "accuracy_threshold", "accuracy": 90, "minAttempts": 5 }
    },
    {
      "id": "perfect_score",
      "name": "Perfectionist",
      "description": "Scored 100% on any test",
      "iconUrl": "https://storage.../badges/perfect.png",
      "criteria": { "type": "perfect_score", "count": 1 }
    },
    {
      "id": "topic_explorer",
      "name": "Topic Explorer",
      "description": "Attempted tests in 5 different topics",
      "iconUrl": "https://storage.../badges/explorer.png",
      "criteria": { "type": "topics_completed", "count": 5 }
    }
  ]
}
```

---

## 9. Testing the Import Workflow

### Step 1 — Prepare a sample question file

Create a `.txt` file in the Drive folder with this format:

```
Q1. What is the capital of France?
A) Berlin
B) Madrid
C) Paris
D) Rome
ANSWER: C
EXPLANATION: Paris has been the capital of France since 987 AD.
---
Q2. Which planet is known as the Red Planet?
A) Venus
B) Mars
C) Jupiter
D) Saturn
ANSWER: B
EXPLANATION: Mars appears reddish due to iron oxide on its surface.
---
```

Name the file: `Geography Basics.txt`
Upload it to the shared Drive folder.

### Step 2 — Get the Drive Folder ID

From the Drive folder URL:
```
https://drive.google.com/drive/folders/1A2B3C4D5E6F7G8H9I0J
                                        ↑ this is the folder ID
```

### Step 3 — Call importDriveContent

From the admin dashboard UI, or using Firebase Functions shell:

```bash
cd firebase/functions
npm run shell
```

```javascript
importDriveContent({ driveFolderId: "1A2B3C4D5E6F7G8H9I0J", adminUid: "your-admin-uid" })
```

### Step 4 — Verify results in Firestore Console

Check:
- `/topics/geography-basics` — topic document created ✓
- `/questions/` — 2 question documents created ✓
- `/tests/geography-basics_test_001` — test document created ✓
- `/adminData/importReports/` — import report created ✓

### Step 5 — Test gradeAttempt

```javascript
gradeAttempt({
  attemptId: "attempt-doc-id",
  testId: "geography-basics_test_001",
  answers: {
    "question-doc-id-1": "C",
    "question-doc-id-2": "B"
  }
})
```

Expected response:

```json
{
  "score": 2,
  "totalQuestions": 2,
  "percentage": 100,
  "accuracy": 100,
  "correct": 2,
  "incorrect": 0,
  "unanswered": 0,
  "results": [
    { "questionId": "...", "isCorrect": true, "correctAnswer": "C", ... },
    { "questionId": "...", "isCorrect": true, "correctAnswer": "B", ... }
  ]
}
```

---

## 10. Emulator (Local Development)

Run the full Firebase emulator suite for local development without affecting production:

```bash
cd firebase/

# Start all emulators
firebase emulators:start

# Start specific emulators
firebase emulators:start --only functions,firestore,auth,hosting
```

Emulator UI: **http://localhost:4000**

| Service | Port |
|---|---|
| Emulator UI | 4000 |
| Authentication | 9099 |
| Firestore | 8080 |
| Cloud Functions | 5001 |
| Hosting | 5000 |

### Point your app to the emulators

```javascript
// In your frontend Firebase initialisation
if (location.hostname === 'localhost') {
  connectFirestoreEmulator(db, 'localhost', 8080);
  connectFunctionsEmulator(functions, 'localhost', 5001);
  connectAuthEmulator(auth, 'http://localhost:9099');
}
```

### Export emulator data for persistence

```bash
firebase emulators:export ./emulator-data
firebase emulators:start --import ./emulator-data
```

---

## 11. Troubleshooting

### Functions fail to deploy: "Billing account not configured"

Upgrade your Firebase project to the **Blaze plan** in the Firebase Console.

### Drive API returns 403 Forbidden

- Verify the service account email has been shared on the Drive folder as **Viewer**
- Confirm `drive.client_email` config is set correctly: `firebase functions:config:get`
- Check the private key has no extra spaces or missing `\n`

### Firestore rules deny read in emulator

- Run `firebase emulators:start` after deploying rules (`firebase deploy --only firestore:rules`) **or** pass rules to the emulator via the `firestore.rules` path in `firebase.json` (already configured)

### "Permission denied" on badge writes from client

Expected behaviour — badges are intentionally write-locked at the rule level and can only be written by Cloud Functions using the Admin SDK. This is by design.

### Custom claim `role: admin` not taking effect

The user must **sign out and sign back in** after the claim is set. Claims are embedded in the ID token, which has a 1-hour TTL.

### TypeScript build errors

```bash
cd functions
npm run build 2>&1 | head -50
```

Common fixes:
- `noUnusedLocals`: remove or prefix with `_` any unused variables
- `strictNullChecks`: add null guards (e.g. `data?.field ?? defaultValue`)

### Firestore indexes not ready

After `firebase deploy --only firestore:indexes`, new composite indexes take **a few minutes** to build. Queries will return a link to the index creation status in the error message.

---

## Quick Reference — Deploy Commands

```bash
# Full deploy
firebase deploy

# Rules + indexes only
firebase deploy --only firestore

# Functions only (after code changes)
cd functions && npm run build && cd .. && firebase deploy --only functions

# Hosting only (after frontend build)
npm run build && firebase deploy --only hosting

# View function logs
firebase functions:log

# View function logs for specific function
firebase functions:log --only gradeAttempt
```

---

*COC Learn & Test — Firebase Backend v1.0.0*
*Setup guide last updated: September 2026*
